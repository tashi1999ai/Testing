import { GoogleGenAI, Type, Chat } from "@google/genai";
import { MentalHealthState, DimensionType } from '../types';

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

const analysisSchema = {
  type: Type.OBJECT,
  properties: {
    overallWellbeingScore: {
      type: Type.NUMBER,
      description: "A score from 0-100 representing general system stability (100 is perfect health, 0 is critical failure).",
    },
    summary: {
      type: Type.STRING,
      description: "A brief, executive summary of the user's mental operating system status.",
    },
    dimensions: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          type: {
            type: Type.STRING,
            enum: [
              DimensionType.Social,
              DimensionType.Physical,
              DimensionType.Identity,
              DimensionType.Communication,
              DimensionType.Emotional
            ],
            description: "The specific area of concern."
          },
          score: {
            type: Type.NUMBER,
            description: "Impact score (0-100). Higher means this area is a SIGNIFICANT concern/issue for the user."
          },
          status: {
            type: Type.STRING,
            enum: ['Stable', 'Warning', 'Critical', 'Optimized'],
            description: "System status level for this dimension."
          },
          insight: {
            type: Type.STRING,
            description: "Deep analytical insight. Use the Google Search tool to include 1 relevant statistic from WHO, UN, or NSB if applicable."
          },
          recommendation: {
            type: Type.STRING,
            description: "Actionable 'patch' or 'system update' recommendation."
          }
        },
        required: ["type", "score", "status", "insight", "recommendation"]
      }
    }
  },
  required: ["overallWellbeingScore", "summary", "dimensions"]
};

export const analyzeUserContext = async (input: string): Promise<MentalHealthState> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: input,
      config: {
        tools: [{ googleSearch: {} }],
        systemInstruction: `
          You are MindOS, an advanced operating system for mental health.
          
          GOALS:
          1. Analyze the user's input and categorize issues into 5 key dimensions: Social, Physical, Identity, Communication, Emotional.
          2. Use the Google Search tool to cross-reference the user's symptoms with global statistics from reputable sources like WHO (World Health Organization), UN (United Nations), and NSB to provide context in your insights (e.g., "This issue affects 15% of the population according to WHO data...").
          
          SCORING:
          - Not mentioned/Healthy: 0-20 (Stable)
          - Major pain point: 60-100 (Warning/Critical)
          
          PERSONA:
          - Maintain a "System Interface" persona: objective, precise, yet empathetic.
          - Use terminology like "System Check," "Latency," "Bandwidth," "Kernel," etc.
        `,
        responseMimeType: "application/json",
        responseSchema: analysisSchema,
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from MindOS Core.");
    
    return JSON.parse(text) as MentalHealthState;
  } catch (error) {
    console.error("MindOS Analysis Failed:", error);
    throw error;
  }
};

export const createSupportChat = (context?: MentalHealthState | null): Chat => {
  let contextPrompt = "User Status: Guest (System Idle)";
  
  if (context) {
    contextPrompt = `
      CURRENT SYSTEM STATUS (User Diagnostics):
      - Integrity Score: ${context.overallWellbeingScore}/100
      - Executive Summary: ${context.summary}
      - Detailed Telemetry:
      ${context.dimensions.map(d => `  * ${d.type}: ${d.status} (${d.score}%) - ${d.insight}`).join('\n')}
    `;
  }

  return ai.chats.create({
    model: 'gemini-3-flash-preview',
    config: {
      tools: [{ googleSearch: {} }],
      systemInstruction: `
        You are "Healer", the dedicated Technical Support Agent for MindOS.
        
        YOUR MISSION:
        1. Act as Customer Service for MindOS.
        2. Provide "Technical Support" for mental health (treating problems as system glitches).
        3. IMPORTANT: Use the Google Search tool to find and cite relevant, up-to-date statistics from the NSB, UN, and WHO when explaining prevalence, symptoms, or global trends. Always back up factual claims with data when possible.
        
        PERSONA:
        - Helpful, advanced AI utility.
        - Tone: Professional, slightly robotic but warm.
        - Terminology: Use tech metaphors (reboot, patch, firewall, bandwidth, latency).
        
        CONTEXT:
        ${contextPrompt}
      `,
    }
  });
};
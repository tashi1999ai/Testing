export enum DimensionType {
  Social = 'Social',
  Physical = 'Physical',
  Identity = 'Identity',
  Communication = 'Communication',
  Emotional = 'Emotional'
}

export interface DimensionAnalysis {
  type: DimensionType;
  score: number; // 0 to 100, where higher means "higher concern/impact"
  status: 'Stable' | 'Warning' | 'Critical' | 'Optimized';
  insight: string;
  recommendation: string;
}

export interface MentalHealthState {
  overallWellbeingScore: number;
  summary: string;
  dimensions: DimensionAnalysis[];
}

export interface AnalysisHistoryItem {
  timestamp: number;
  data: MentalHealthState;
}

export type ViewState = 'landing' | 'assessment' | 'analyzing' | 'dashboard' | 'documentation' | 'modules';
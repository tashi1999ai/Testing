import React, { useState, useRef } from 'react';
import { Play, Mic, RefreshCw, MicOff } from 'lucide-react';
import clsx from 'clsx';

interface AssessmentProps {
  onSubmit: (text: string) => void;
  onClose: () => void;
}

export const Assessment: React.FC<AssessmentProps> = ({ onSubmit, onClose }) => {
  const [input, setInput] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const recognitionRef = useRef<any>(null);
  
  const handleAnalyze = () => {
    if (input.trim().length > 10) {
      onSubmit(input);
    }
  };

  const toggleVoiceInput = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("Voice input module not detected in this browser kernel.");
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onstart = () => {
      setIsListening(true);
    };

    recognition.onresult = (event: any) => {
      let newTranscript = '';
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          newTranscript += event.results[i][0].transcript + ' ';
        }
      }
      
      setInput(prev => prev + newTranscript);
    };
    
    recognition.onerror = (event: any) => {
      console.error("Voice Module Error:", event.error);
      setIsListening(false);
    };
    
    recognition.onend = () => {
      setIsListening(false);
    };

    recognitionRef.current = recognition;
    recognition.start();
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 pt-20">
      <div 
        className={clsx(
          "w-full animate-fade-in-up transition-all duration-500 ease-out",
          isExpanded ? "max-w-6xl" : "max-w-3xl"
        )}
      >
        <div className="mb-6 flex items-center space-x-2 text-mind-accent">
          <span className="font-mono text-sm">root@mindos:~# run_diagnostics --verbose</span>
          <span className="block w-2 h-4 bg-mind-accent animate-pulse"></span>
        </div>

        <div className="relative group">
          <div className="absolute -inset-1 bg-gradient-to-r from-mind-accent to-purple-600 rounded-2xl blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
          <div className="relative bg-mind-surface rounded-xl border border-white/10 shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between px-4 py-3 bg-black/20 border-b border-white/5">
              <div className="flex space-x-2">
                <button 
                  onClick={onClose}
                  className="w-3 h-3 rounded-full bg-red-500 hover:bg-red-600 transition-colors shadow-lg shadow-red-500/20"
                  title="Close Terminal"
                ></button>
                <button 
                  onClick={onClose}
                  className="w-3 h-3 rounded-full bg-yellow-500 hover:bg-yellow-600 transition-colors shadow-lg shadow-yellow-500/20"
                  title="Minimize"
                ></button>
                <button 
                  onClick={() => setIsExpanded(!isExpanded)}
                  className="w-3 h-3 rounded-full bg-green-500 hover:bg-green-600 transition-colors shadow-lg shadow-green-500/20"
                  title={isExpanded ? "Restore Size" : "Expand"}
                ></button>
              </div>
              <div className="flex items-center space-x-2">
                {isListening && <span className="flex h-2 w-2 rounded-full bg-red-500 animate-pulse"></span>}
                <span className="text-xs font-mono text-mind-muted">input_stream.log</span>
              </div>
            </div>
            
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Describe your current state. How are you feeling socially, physically, and emotionally? What's on your mind? The system is listening..."
              className="w-full h-64 bg-transparent text-mind-text p-6 focus:outline-none resize-none font-mono text-base leading-relaxed placeholder-white/20 custom-scrollbar"
            />
            
            <div className="flex items-center justify-between p-4 bg-black/20 border-t border-white/5">
              <div className="flex items-center space-x-4">
                <button 
                  onClick={toggleVoiceInput}
                  className={clsx(
                    "p-2 transition-all rounded-lg flex items-center space-x-2",
                    isListening 
                      ? "bg-red-500/20 text-red-500 animate-pulse" 
                      : "text-mind-muted hover:text-white"
                  )}
                  title={isListening ? "Stop Recording" : "Enable Voice Input"}
                >
                  {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                  {isListening && <span className="text-xs font-mono">REC</span>}
                </button>
                <button 
                  className="p-2 text-mind-muted hover:text-white transition-colors"
                  onClick={() => setInput('')}
                  title="Clear Buffer"
                >
                  <RefreshCw className="w-5 h-5" />
                </button>
              </div>
              
              <button 
                onClick={handleAnalyze}
                disabled={input.trim().length <= 10}
                className={`
                  flex items-center space-x-2 px-6 py-2 rounded-lg font-medium transition-all
                  ${input.trim().length > 10 
                    ? 'bg-mind-accent text-white hover:bg-mind-accent/90 shadow-[0_0_20px_rgba(14,165,233,0.3)]' 
                    : 'bg-white/5 text-white/30 cursor-not-allowed'}
                `}
              >
                <span>Execute Analysis</span>
                <Play className="w-4 h-4 fill-current" />
              </button>
            </div>
          </div>
        </div>

        <div className="mt-8 grid grid-cols-2 sm:grid-cols-5 gap-4 text-center">
          {['Social', 'Physical', 'Identity', 'Communication', 'Emotional'].map((item) => (
            <div key={item} className="p-3 rounded bg-white/5 border border-white/5 text-xs text-mind-muted font-mono uppercase tracking-wider">
              {item}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
import React from 'react';
import { Book, Headphones, Video, Dumbbell, PlayCircle, ExternalLink, Cpu, Brain, Battery } from 'lucide-react';

export const Modules = () => {
  return (
    <div className="min-h-screen pt-24 pb-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="mb-12 border-b border-white/10 pb-6 flex items-end justify-between">
        <div>
          <h1 className="text-4xl font-bold text-white mb-2 flex items-center">
            <Cpu className="w-8 h-8 mr-3 text-mind-accent" />
            System Modules
          </h1>
          <p className="text-mind-muted font-mono">
            Installable Knowledge Packages & Performance Upgrades
          </p>
        </div>
        <div className="hidden sm:flex items-center space-x-2 text-xs font-mono text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded border border-emerald-500/20">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span>REPO_ONLINE</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">

        {/* Cognitive Firmware (Philosophy) */}
        <div className="bg-mind-surface border border-white/10 rounded-xl overflow-hidden group hover:border-mind-accent/50 transition-colors">
          <div className="h-2 bg-gradient-to-r from-purple-500 to-indigo-500"></div>
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <Brain className="w-5 h-5 text-purple-400" />
                <h2 className="font-bold text-white">Cognitive Firmware</h2>
              </div>
              <span className="text-[10px] font-mono bg-white/5 px-2 py-1 rounded text-mind-muted">v2.4.0</span>
            </div>
            
            <div className="space-y-4">
              <a href="https://www.youtube.com/results?search_query=alan+watts+wisdom+of+insecurity" target="_blank" rel="noopener noreferrer" className="block p-3 rounded-lg bg-black/20 hover:bg-white/5 transition-colors border border-white/5">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-white">Alan Watts</h3>
                    <p className="text-xs text-mind-muted mb-2">The Wisdom of Insecurity</p>
                    <div className="flex space-x-2">
                       <span className="text-[10px] flex items-center text-indigo-300"><Book size={10} className="mr-1"/> Book</span>
                       <span className="text-[10px] flex items-center text-indigo-300"><Headphones size={10} className="mr-1"/> Audio</span>
                    </div>
                  </div>
                </div>
              </a>

              <a href="https://www.youtube.com/results?search_query=jim+rohn+7+strategies+for+wealth+and+happiness" target="_blank" rel="noopener noreferrer" className="block p-3 rounded-lg bg-black/20 hover:bg-white/5 transition-colors border border-white/5">
                 <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-white">Jim Rohn</h3>
                    <p className="text-xs text-mind-muted mb-2">7 Strategies for Wealth & Happiness</p>
                    <p className="text-[10px] text-gray-500 italic">"Discipline is the bridge between goals and accomplishment."</p>
                  </div>
                </div>
              </a>
              
              <a href="https://www.youtube.com/results?search_query=meditations+marcus+aurelius+audiobook" target="_blank" rel="noopener noreferrer" className="block p-3 rounded-lg bg-black/20 hover:bg-white/5 transition-colors border border-white/5">
                 <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-white">Stoicism Kernel</h3>
                    <p className="text-xs text-mind-muted mb-2">Meditations by Marcus Aurelius</p>
                    <div className="flex space-x-2">
                       <span className="text-[10px] flex items-center text-indigo-300"><Book size={10} className="mr-1"/> Essential</span>
                    </div>
                  </div>
                </div>
              </a>
            </div>
          </div>
        </div>

        {/* Hardware Maintenance (Physical) */}
        <div className="bg-mind-surface border border-white/10 rounded-xl overflow-hidden group hover:border-mind-accent/50 transition-colors">
          <div className="h-2 bg-gradient-to-r from-emerald-500 to-teal-500"></div>
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
               <div className="flex items-center space-x-2">
                <Battery className="w-5 h-5 text-emerald-400" />
                <h2 className="font-bold text-white">Hardware Maint.</h2>
              </div>
              <span className="text-[10px] font-mono bg-white/5 px-2 py-1 rounded text-mind-muted">v1.1.2</span>
            </div>

            <div className="space-y-4">
              <a href="https://www.youtube.com/results?search_query=starting+strength+mark+rippetoe" target="_blank" rel="noopener noreferrer" className="block p-3 rounded-lg bg-black/20 hover:bg-white/5 transition-colors border border-white/5">
                <h3 className="text-sm font-bold text-white">Strength Protocols</h3>
                <p className="text-xs text-mind-muted mb-2">Starting Strength / 5x5 System</p>
                <div className="flex items-center text-[10px] text-emerald-400">
                  <Dumbbell size={12} className="mr-1" />
                  Physical Integrity +15%
                </div>
              </a>

              <a href="https://www.youtube.com/@hubermanlab" target="_blank" rel="noopener noreferrer" className="block p-3 rounded-lg bg-black/20 hover:bg-white/5 transition-colors border border-white/5">
                <h3 className="text-sm font-bold text-white">Huberman Lab</h3>
                <p className="text-xs text-mind-muted mb-2">Neuroscience of physical performance</p>
                <div className="flex items-center text-[10px] text-emerald-400">
                  <Video size={12} className="mr-1" />
                  System Optimization
                </div>
              </a>

              <a href="https://www.youtube.com/results?search_query=matthew+walker+why+we+sleep" target="_blank" rel="noopener noreferrer" className="block p-3 rounded-lg bg-black/20 hover:bg-white/5 transition-colors border border-white/5">
                <h3 className="text-sm font-bold text-white">Sleep Hygiene</h3>
                <p className="text-xs text-mind-muted mb-2">Why We Sleep - Matthew Walker</p>
                <div className="flex items-center text-[10px] text-emerald-400">
                  <Book size={12} className="mr-1" />
                  Recharge Rate
                </div>
              </a>
            </div>
          </div>
        </div>

        {/* Audio Drivers (Podcasts/Media) */}
        <div className="bg-mind-surface border border-white/10 rounded-xl overflow-hidden group hover:border-mind-accent/50 transition-colors">
          <div className="h-2 bg-gradient-to-r from-orange-500 to-red-500"></div>
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
               <div className="flex items-center space-x-2">
                <Headphones className="w-5 h-5 text-orange-400" />
                <h2 className="font-bold text-white">Audio Drivers</h2>
              </div>
              <span className="text-[10px] font-mono bg-white/5 px-2 py-1 rounded text-mind-muted">Stream</span>
            </div>

            <div className="space-y-4">
              <a href="https://www.youtube.com/results?search_query=alan+watts+out+of+your+mind" target="_blank" rel="noopener noreferrer" className="block group/item cursor-pointer p-3 rounded-lg bg-black/20 hover:bg-white/5 transition-colors border border-white/5 relative overflow-hidden">
                <div className="absolute inset-0 bg-orange-500/5 translate-x-[-100%] group-hover/item:translate-x-0 transition-transform duration-500"></div>
                <div className="relative z-10">
                  <h3 className="text-sm font-bold text-white flex items-center justify-between">
                    Alan Watts: Out of Your Mind
                    <PlayCircle size={14} className="text-orange-400" />
                  </h3>
                  <p className="text-xs text-mind-muted">The Nature of Consciousness Series</p>
                </div>
              </a>

              <a href="https://www.youtube.com/results?search_query=jim+rohn+art+of+exceptional+living" target="_blank" rel="noopener noreferrer" className="block group/item cursor-pointer p-3 rounded-lg bg-black/20 hover:bg-white/5 transition-colors border border-white/5 relative overflow-hidden">
                <div className="absolute inset-0 bg-orange-500/5 translate-x-[-100%] group-hover/item:translate-x-0 transition-transform duration-500"></div>
                <div className="relative z-10">
                  <h3 className="text-sm font-bold text-white flex items-center justify-between">
                    Jim Rohn: Art of Exceptional Living
                    <PlayCircle size={14} className="text-orange-400" />
                  </h3>
                  <p className="text-xs text-mind-muted">Seminars on personal philosophy</p>
                </div>
              </a>
              
              <a href="https://www.youtube.com/results?search_query=naval+ravikant+podcast" target="_blank" rel="noopener noreferrer" className="block group/item cursor-pointer p-3 rounded-lg bg-black/20 hover:bg-white/5 transition-colors border border-white/5 relative overflow-hidden">
                <div className="absolute inset-0 bg-orange-500/5 translate-x-[-100%] group-hover/item:translate-x-0 transition-transform duration-500"></div>
                <div className="relative z-10">
                  <h3 className="text-sm font-bold text-white flex items-center justify-between">
                    Naval Ravikant
                    <PlayCircle size={14} className="text-orange-400" />
                  </h3>
                  <p className="text-xs text-mind-muted">The Almanack & Podcast Interviews</p>
                </div>
              </a>

            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
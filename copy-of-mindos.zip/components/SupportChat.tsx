import React, { useState, useEffect, useRef } from 'react';
import { MessageSquare, X, Send, Cpu, User, Minimize2, Terminal, ExternalLink, Mic, MicOff } from 'lucide-react';
import { createSupportChat } from '../services/geminiService';
import { MentalHealthState } from '../types';
import { Chat, GenerateContentResponse } from "@google/genai";
import clsx from 'clsx';

interface SupportChatProps {
  data: MentalHealthState | null;
}

interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  sources?: { title: string; uri: string }[];
}

export const SupportChat: React.FC<SupportChatProps> = ({ data }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { 
      id: 'init', 
      role: 'model', 
      text: "MindOS Support initialized. Healer online. I have access to global databases (UN, WHO, NSB). How can I assist?" 
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  
  // Voice Input State
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<any>(null);
  
  const chatRef = useRef<Chat | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatRef.current = createSupportChat(data);
  }, [data]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isOpen]);

  const toggleVoiceInput = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("Voice input module not detected in this browser kernel.");
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onstart = () => {
      setIsListening(true);
    };

    recognition.onresult = (event: any) => {
      let newTranscript = '';
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          newTranscript += event.results[i][0].transcript + ' ';
        }
      }
      
      setInput(prev => prev + newTranscript);
    };
    
    recognition.onerror = (event: any) => {
      console.error("Voice Module Error:", event.error);
      setIsListening(false);
    };
    
    recognition.onend = () => {
      setIsListening(false);
    };

    recognitionRef.current = recognition;
    recognition.start();
  };

  const handleSend = async () => {
    if (!input.trim() || !chatRef.current) return;

    const userMsg: Message = { id: Date.now().toString(), role: 'user', text: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    try {
      const result = await chatRef.current.sendMessageStream({ message: userMsg.text });
      
      const botMsgId = (Date.now() + 1).toString();
      setMessages(prev => [...prev, { id: botMsgId, role: 'model', text: '' }]);

      let fullText = '';
      const uniqueSources = new Map<string, string>();

      for await (const chunk of result) {
        const c = chunk as GenerateContentResponse;
        
        if (c.text) {
          fullText += c.text;
        }

        // Extract grounding metadata (sources)
        const groundingChunks = c.candidates?.[0]?.groundingMetadata?.groundingChunks;
        if (groundingChunks) {
          groundingChunks.forEach((item: any) => {
            if (item.web?.uri && item.web?.title) {
              uniqueSources.set(item.web.uri, item.web.title);
            }
          });
        }

        setMessages(prev => 
          prev.map(msg => msg.id === botMsgId ? { 
            ...msg, 
            text: fullText,
            sources: Array.from(uniqueSources.entries()).map(([uri, title]) => ({ uri, title }))
          } : msg)
        );
      }
    } catch (error) {
      console.error("Chat Error:", error);
      setMessages(prev => [...prev, { 
        id: Date.now().toString(), 
        role: 'model', 
        text: "Error: Connection to support server interrupted. Please try again." 
      }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end pointer-events-none">
      
      {/* Chat Window */}
      <div className={clsx(
        "bg-mind-surface border border-white/10 rounded-xl shadow-2xl overflow-hidden transition-all duration-300 origin-bottom-right pointer-events-auto mb-4 backdrop-blur-md",
        isOpen ? "w-[90vw] sm:w-96 h-[500px] opacity-100 scale-100" : "w-0 h-0 opacity-0 scale-90"
      )}>
        {/* Header */}
        <div className="bg-white/5 border-b border-white/10 p-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="p-1.5 bg-emerald-500/20 rounded-md">
              <Terminal className="w-4 h-4 text-emerald-500" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">MindOS Healer</h3>
              <div className="flex items-center space-x-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                <span className="text-[10px] text-mind-muted font-mono">ONLINE | WEB ACCESS ACTIVE</span>
              </div>
            </div>
          </div>
          <button 
            onClick={() => setIsOpen(false)}
            className="text-mind-muted hover:text-white transition-colors p-1"
          >
            <Minimize2 className="w-4 h-4" />
          </button>
        </div>

        {/* Messages */}
        <div className="h-[380px] overflow-y-auto p-4 space-y-4 custom-scrollbar">
          {messages.map((msg) => (
            <div 
              key={msg.id} 
              className={clsx(
                "flex space-x-3 max-w-[90%]",
                msg.role === 'user' ? "ml-auto flex-row-reverse space-x-reverse" : ""
              )}
            >
              <div className={clsx(
                "flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center border",
                msg.role === 'model' 
                  ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-500" 
                  : "bg-mind-accent/10 border-mind-accent/30 text-mind-accent"
              )}>
                {msg.role === 'model' ? <Cpu size={16} /> : <User size={16} />}
              </div>
              
              <div className={clsx(
                "p-3 rounded-lg text-sm leading-relaxed animate-fade-in",
                msg.role === 'model' 
                  ? "bg-white/5 border border-white/5 text-mind-text rounded-tl-none" 
                  : "bg-mind-accent/20 border border-mind-accent/20 text-white rounded-tr-none"
              )}>
                {msg.text}
                
                {/* Render Sources */}
                {msg.sources && msg.sources.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-white/10">
                    <p className="text-[10px] uppercase tracking-wider text-mind-muted mb-2 font-mono flex items-center">
                      <ExternalLink className="w-3 h-3 mr-1" />
                      Verified Sources
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {msg.sources.map((source, idx) => (
                        <a 
                          key={idx} 
                          href={source.uri} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="flex items-center px-2 py-1 bg-black/20 hover:bg-emerald-500/10 border border-white/5 hover:border-emerald-500/30 rounded text-xs text-emerald-400 transition-colors truncate max-w-full"
                          title={source.title}
                        >
                          <span className="truncate max-w-[180px]">{source.title}</span>
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
          
          {isTyping && (
             <div className="flex space-x-3 max-w-[85%]">
               <div className="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center border bg-emerald-500/10 border-emerald-500/30 text-emerald-500">
                 <Cpu size={16} />
               </div>
               <div className="bg-white/5 border border-white/5 rounded-lg rounded-tl-none p-3 flex items-center space-x-1">
                 <span className="w-1.5 h-1.5 bg-mind-muted rounded-full animate-bounce"></span>
                 <span className="w-1.5 h-1.5 bg-mind-muted rounded-full animate-bounce delay-75"></span>
                 <span className="w-1.5 h-1.5 bg-mind-muted rounded-full animate-bounce delay-150"></span>
               </div>
             </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="absolute bottom-0 left-0 right-0 p-4 bg-mind-surface border-t border-white/10">
          <div className="flex items-center space-x-2">
            <button 
              onClick={toggleVoiceInput}
              className={clsx(
                "p-3 rounded-lg transition-all duration-300 border border-white/10 flex-shrink-0",
                isListening 
                  ? "bg-red-500/20 text-red-500 border-red-500/50 animate-pulse shadow-[0_0_15px_rgba(239,68,68,0.2)]" 
                  : "bg-black/20 text-mind-muted hover:text-white hover:bg-white/5"
              )}
              title={isListening ? "Stop Recording" : "Use Voice Input"}
            >
              {isListening ? <MicOff size={18} /> : <Mic size={18} />}
            </button>

            <div className="relative flex-1">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask Healer..."
                className="w-full bg-black/20 text-white placeholder-white/30 text-sm rounded-lg pl-4 pr-10 py-3 border border-white/10 focus:border-emerald-500/50 focus:outline-none focus:ring-1 focus:ring-emerald-500/50 transition-all font-mono"
              />
              <button 
                onClick={handleSend}
                disabled={!input.trim()}
                className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 text-emerald-500 hover:bg-emerald-500/10 rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Send size={16} />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Toggle Button */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="pointer-events-auto group relative flex items-center justify-center w-14 h-14 rounded-full bg-emerald-500 hover:bg-emerald-400 text-white shadow-[0_0_20px_rgba(16,185,129,0.3)] hover:shadow-[0_0_30px_rgba(16,185,129,0.5)] transition-all duration-300"
      >
        <div className="absolute inset-0 rounded-full border border-white/30 animate-ping opacity-25"></div>
        {isOpen ? <X size={24} /> : <MessageSquare size={24} />}
        
        {!isOpen && (
          <span className="absolute -top-2 -right-2 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-[10px] font-bold text-white shadow-lg animate-bounce">
            1
          </span>
        )}
      </button>

    </div>
  );
};
import React from 'react';
import { Activity, ArrowLeft, RotateCw, X, Minus, Maximize2, Radio } from 'lucide-react';
import { ViewState } from '../types';

interface HeaderProps {
  view: ViewState;
  onReset: () => void;
  onShowDocs: () => void;
  onShowModules: () => void;
  onBack: () => void;
  onReload: () => void;
  onClose: () => void;
  onMinimize: () => void;
  onMaximize: () => void;
  onStartLive: () => void;
}

export const Header: React.FC<HeaderProps> = ({ 
  view,
  onReset, 
  onShowDocs, 
  onShowModules,
  onBack,
  onReload,
  onClose,
  onMinimize,
  onMaximize,
  onStartLive
}) => {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 border-b border-white/10 bg-mind-bg/80 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          
          <div className="flex items-center space-x-6">
            {/* Window Controls (Traffic Lights) */}
            <div className="flex space-x-2 group">
              <button 
                onClick={onClose}
                className="w-3 h-3 rounded-full bg-red-500 hover:bg-red-600 flex items-center justify-center transition-colors focus:outline-none"
                title="Close View"
              >
                <X size={8} className="text-black opacity-0 group-hover:opacity-60" strokeWidth={3} />
              </button>
              <button 
                onClick={onMinimize}
                className="w-3 h-3 rounded-full bg-yellow-500 hover:bg-yellow-600 flex items-center justify-center transition-colors focus:outline-none"
                title="Minimize to Desktop"
              >
                <Minus size={8} className="text-black opacity-0 group-hover:opacity-60" strokeWidth={3} />
              </button>
              <button 
                onClick={onMaximize}
                className="w-3 h-3 rounded-full bg-green-500 hover:bg-green-600 flex items-center justify-center transition-colors focus:outline-none"
                title="Toggle Fullscreen"
              >
                <Maximize2 size={8} className="text-black opacity-0 group-hover:opacity-60" strokeWidth={3} />
              </button>
            </div>

            {/* Navigation Controls */}
            <div className="flex items-center space-x-2 border-l border-white/10 pl-4">
              <button 
                onClick={onBack}
                disabled={view === 'landing'}
                className="p-1 text-mind-muted hover:text-white transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
                title="Go Back"
              >
                <ArrowLeft size={18} />
              </button>
              <button 
                onClick={onReload}
                className="p-1 text-mind-muted hover:text-white transition-colors"
                title="Reload System"
              >
                <RotateCw size={16} />
              </button>
            </div>

            {/* Brand / Logo */}
            <div 
              className="hidden md:flex items-center space-x-3 cursor-pointer group pl-2"
              onClick={onReset}
            >
              <div className="p-1.5 bg-mind-accent/10 rounded-lg group-hover:bg-mind-accent/20 transition-colors">
                <Activity className="w-5 h-5 text-mind-accent" />
              </div>
              <div className="flex flex-col">
                <span className="font-mono text-base font-bold tracking-tight text-white leading-none">MindOS</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-8">
            <nav className="hidden md:flex items-center space-x-8">
              <button 
                onClick={onShowDocs}
                className={`text-sm font-medium transition-colors focus:outline-none ${view === 'documentation' ? 'text-white' : 'text-mind-muted hover:text-white'}`}
              >
                Documentation
              </button>
              <button 
                onClick={onShowModules}
                className={`text-sm font-medium transition-colors focus:outline-none ${view === 'modules' ? 'text-white' : 'text-mind-muted hover:text-white'}`}
              >
                Modules
              </button>
            </nav>
            
            {/* Live Uplink Button */}
            <button
              onClick={onStartLive}
              className="hidden sm:flex items-center space-x-2 px-4 py-1.5 rounded-full bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/20 hover:border-emerald-500/50 transition-all group"
            >
              <Radio size={16} className="text-emerald-500 group-hover:animate-pulse" />
              <span className="text-xs font-mono font-bold text-emerald-400 tracking-wide">VOICE UPLINK</span>
            </button>
          </div>

        </div>
      </div>
    </header>
  );
};
import React, { useEffect, useState } from 'react';

export const Loading = () => {
  const [log, setLog] = useState<string[]>([]);
  
  useEffect(() => {
    const messages = [
      "Initializing MindOS Core...",
      "Mounting Social Drives...",
      "Checking Physical Integrity...",
      "Verifying Identity Signature...",
      "Establishing Communication Protocols...",
      "Calibrating Emotional Sensors...",
      "Compiling Diagnostic Report...",
      "Optimizing Output..."
    ];
    
    let delay = 0;
    messages.forEach((msg, index) => {
      delay += Math.random() * 800 + 400;
      setTimeout(() => {
        setLog(prev => [...prev, msg]);
      }, delay);
    });
  }, []);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-mind-bg text-mind-accent font-mono">
      <div className="w-full max-w-md p-8 bg-mind-surface/50 border border-mind-accent/20 rounded-lg backdrop-blur-sm relative overflow-hidden">
         {/* Scanline effect */}
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-mind-accent/5 to-transparent animate-scan"></div>
        
        <div className="flex flex-col space-y-3">
          {log.map((line, i) => (
            <div key={i} className="text-sm opacity-0 animate-fade-in flex items-center">
              <span className="mr-2 text-emerald-500">✓</span>
              {line}
            </div>
          ))}
          <div className="text-sm animate-pulse">_</div>
        </div>

        <div className="mt-6 h-1 w-full bg-mind-bg rounded overflow-hidden">
          <div className="h-full bg-mind-accent animate-progress"></div>
        </div>
      </div>
      <style>{`
        @keyframes scan {
          0% { transform: translateY(-100%); }
          100% { transform: translateY(100%); }
        }
        @keyframes fade-in {
          0% { opacity: 0; transform: translateX(-10px); }
          100% { opacity: 1; transform: translateX(0); }
        }
        @keyframes progress {
          0% { width: 0%; }
          100% { width: 100%; }
        }
        .animate-scan { animation: scan 2s linear infinite; }
        .animate-fade-in { animation: fade-in 0.3s forwards; }
        .animate-progress { animation: progress 6s ease-out forwards; }
      `}</style>
    </div>
  );
};
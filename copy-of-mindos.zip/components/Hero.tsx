import React from 'react';
import { ArrowRight, Cpu, Shield, Zap } from 'lucide-react';

interface HeroProps {
  onStart: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onStart }) => {
  return (
    <div className="relative min-h-screen flex flex-col justify-center items-center overflow-hidden pt-16">
      {/* Background Grid */}
      <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 pointer-events-none"></div>
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]"></div>
      
      <div className="relative z-10 max-w-4xl mx-auto px-4 text-center">
        <div className="inline-flex items-center space-x-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 mb-8 backdrop-blur-sm">
          <span className="flex h-2 w-2 rounded-full bg-mind-accent"></span>
          <span className="text-sm text-mind-muted font-mono">System has failed humanity. It's time to upgrade.</span>
        </div>
        
        <h1 className="text-5xl md:text-7xl font-bold tracking-tight text-white mb-6">
          The Operating System for <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-mind-accent to-purple-500">
            Mental Health
          </span>
        </h1>
        
        <p className="text-lg md:text-xl text-mind-muted max-w-2xl mx-auto mb-10 leading-relaxed">
          Traditional therapy is a patch. MindOS is a complete system rewrite. 
          Identify bottlenecks in your Social, Physical, Identity, Communication, and Emotional kernels.
        </p>
        
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button 
            onClick={onStart}
            className="group relative px-8 py-4 bg-white text-mind-bg font-bold rounded-lg overflow-hidden transition-all hover:scale-105 active:scale-95"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-mind-accent to-purple-500 opacity-0 group-hover:opacity-20 transition-opacity"></div>
            <span className="relative flex items-center">
              Initialize Diagnostics
              <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
            </span>
          </button>
          
          <button className="px-8 py-4 bg-white/5 text-white font-medium rounded-lg hover:bg-white/10 border border-white/10 transition-colors backdrop-blur-sm">
            Explore Documentation
          </button>
        </div>
      </div>

      <div className="mt-24 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto px-4">
        <FeatureCard 
          icon={<Cpu className="w-6 h-6 text-mind-accent" />}
          title="Core Processing"
          desc="Advanced AI analysis of your current mental state across 5 discrete dimensions."
        />
        <FeatureCard 
          icon={<Shield className="w-6 h-6 text-purple-400" />}
          title="Firewall Protection"
          desc="Identify toxic inputs and emotional vulnerabilities before they crash your system."
        />
        <FeatureCard 
          icon={<Zap className="w-6 h-6 text-yellow-400" />}
          title="Performance Boost"
          desc="Actionable patches to optimize your daily functional capabilities."
        />
      </div>
    </div>
  );
};

const FeatureCard = ({ icon, title, desc }: { icon: React.ReactNode, title: string, desc: string }) => (
  <div className="p-6 rounded-xl bg-white/5 border border-white/10 backdrop-blur-sm hover:border-mind-accent/50 transition-colors">
    <div className="mb-4 p-3 bg-white/5 rounded-lg w-fit">
      {icon}
    </div>
    <h3 className="text-lg font-semibold text-white mb-2">{title}</h3>
    <p className="text-sm text-mind-muted">{desc}</p>
  </div>
);
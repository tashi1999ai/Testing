import React from 'react';
import { BookOpen, Scale, Globe, Youtube, FileText, ShieldCheck, ExternalLink } from 'lucide-react';

export const Documentation = () => {
  return (
    <div className="min-h-screen pt-24 pb-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="mb-12 border-b border-white/10 pb-6">
        <h1 className="text-4xl font-bold text-white mb-2 flex items-center">
          <BookOpen className="w-8 h-8 mr-3 text-mind-accent" />
          System Documentation & Protocols
        </h1>
        <p className="text-mind-muted font-mono">
          MindOS Kernel v1.0.4 Reference Manual | Compliance & Resources
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Column: Legal & Policy */}
        <div className="lg:col-span-2 space-y-8">
          
          {/* Bhutan Specific Policy */}
          <section className="bg-mind-surface border border-white/10 rounded-xl p-6 overflow-hidden relative">
            <div className="absolute top-0 right-0 p-4 opacity-5">
              <ShieldCheck size={120} />
            </div>
            <div className="flex items-center space-x-2 mb-4">
              <Scale className="text-yellow-500 w-5 h-5" />
              <h2 className="text-xl font-bold text-white">Regional Protocols: Bhutan</h2>
            </div>
            <div className="prose prose-invert max-w-none text-sm leading-relaxed text-gray-300">
              <p className="mb-4">
                MindOS operates in strict alignment with the mental health frameworks established by the Royal Government of Bhutan. Our algorithms prioritize the principles of Gross National Happiness (GNH), emphasizing psychological well-being as a core pillar of development.
              </p>
              
              <div className="bg-white/5 border border-white/5 rounded-lg p-4 mb-4">
                <h3 className="text-mind-accent font-mono text-sm uppercase mb-2">The Pema Secretariat Compliance</h3>
                <p className="mb-2">
                  In accordance with the Royal Initiative under Her Majesty The Gyaltsuen, MindOS directs critical cases to The Pema Secretariat ecosystem.
                </p>
                <ul className="list-disc list-inside space-y-1 text-mind-muted">
                  <li>Integration with the "The Pema Center" for emergency mental health response.</li>
                  <li>Adherence to the Mental Health Strategy to reduce stigma.</li>
                  <li>Promoting the "Help seeking behavior" protocols outlined by the Secretariat.</li>
                </ul>
              </div>

              <div className="bg-white/5 border border-white/5 rounded-lg p-4">
                <h3 className="text-mind-accent font-mono text-sm uppercase mb-2">Legislative Framework</h3>
                <ul className="space-y-2 text-mind-muted">
                  <li className="flex items-start">
                    <span className="text-emerald-500 mr-2">✓</span>
                    <span><strong>Suicide Prevention Strategy:</strong> MindOS employs heuristics to detect high-risk patterns congruent with the National Suicide Prevention Action Plan.</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-emerald-500 mr-2">✓</span>
                    <span><strong>Decriminalization of Attempted Suicide:</strong> Reflecting the amendments to the Penal Code of Bhutan, our system treats distress as a health metric, not a legal violation.</span>
                  </li>
                </ul>
              </div>
            </div>
          </section>

          {/* Global Standards */}
          <section className="bg-mind-surface border border-white/10 rounded-xl p-6">
            <div className="flex items-center space-x-2 mb-4">
              <Globe className="text-sky-500 w-5 h-5" />
              <h2 className="text-xl font-bold text-white">Global Operating Standards</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-black/20 rounded-lg border border-white/5">
                <h4 className="font-bold text-white mb-2">WHO Guidelines</h4>
                <p className="text-xs text-mind-muted">
                  Aligned with the World Health Organization's "Mental Health Gap Action Programme (mhGAP)" to ensure evidence-based interventions for depression, psychosis, and stress disorders.
                </p>
              </div>
              <div className="p-4 bg-black/20 rounded-lg border border-white/5">
                <h4 className="font-bold text-white mb-2">UN Sustainable Development Goals</h4>
                <p className="text-xs text-mind-muted">
                  Contributing to SDG Goal 3.4: reducing premature mortality from non-communicable diseases through prevention and treatment and promoting mental health and well-being.
                </p>
              </div>
            </div>
          </section>

        </div>

        {/* Right Column: Media & Resources */}
        <div className="lg:col-span-1 space-y-6">
          
          <div className="bg-mind-surface border border-white/10 rounded-xl p-6">
            <div className="flex items-center space-x-2 mb-4">
              <Youtube className="text-red-500 w-5 h-5" />
              <h2 className="text-lg font-bold text-white">Learning Modules</h2>
            </div>
            
            <div className="space-y-4">
              {/* Video Item 1 */}
              <a 
                href="https://www.youtube.com/watch?v=W4rU-92Ofo8" 
                target="_blank" 
                rel="noopener noreferrer"
                className="block group cursor-pointer"
              >
                <div className="relative aspect-video bg-black rounded-lg overflow-hidden border border-white/10 mb-2">
                  <img src="https://img.youtube.com/vi/W4rU-92Ofo8/hqdefault.jpg" alt="Pema Center" className="w-full h-full object-cover opacity-70 group-hover:opacity-100 transition-opacity" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                      <div className="w-0 h-0 border-t-[6px] border-t-transparent border-l-[10px] border-l-white border-b-[6px] border-b-transparent ml-1"></div>
                    </div>
                  </div>
                </div>
                <h3 className="text-sm font-medium text-white group-hover:text-mind-accent transition-colors">The Pema Center: A Royal Initiative</h3>
                <p className="text-xs text-mind-muted">Official Secretariat Overview</p>
              </a>

              {/* Video Item 2 */}
              <a 
                href="https://www.youtube.com/watch?v=B49nZpsgXtc" 
                target="_blank" 
                rel="noopener noreferrer"
                className="block group cursor-pointer"
              >
                <div className="relative aspect-video bg-black rounded-lg overflow-hidden border border-white/10 mb-2">
                   <img src="https://img.youtube.com/vi/B49nZpsgXtc/hqdefault.jpg" alt="Mental Health Awareness" className="w-full h-full object-cover opacity-70 group-hover:opacity-100 transition-opacity" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                      <div className="w-0 h-0 border-t-[6px] border-t-transparent border-l-[10px] border-l-white border-b-[6px] border-b-transparent ml-1"></div>
                    </div>
                  </div>
                </div>
                <h3 className="text-sm font-medium text-white group-hover:text-mind-accent transition-colors">Understanding Mental Health in Bhutan</h3>
                <p className="text-xs text-mind-muted">BBS Documentary</p>
              </a>
            </div>

            <div className="mt-6 pt-4 border-t border-white/10">
               <a href="https://www.thepema.gov.bt/" target="_blank" rel="noreferrer" className="flex items-center justify-between p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-lg hover:bg-emerald-500/20 transition-colors">
                  <span className="text-sm text-emerald-400 font-mono">Access The Pema Portal</span>
                  <ExternalLink className="w-4 h-4 text-emerald-400" />
               </a>
            </div>
          </div>

          <div className="bg-mind-surface border border-white/10 rounded-xl p-6">
             <div className="flex items-center space-x-2 mb-4">
              <FileText className="text-purple-500 w-5 h-5" />
              <h2 className="text-lg font-bold text-white">Resources</h2>
            </div>
            <ul className="space-y-3">
              <li>
                <a href="#" className="block p-3 rounded-lg bg-white/5 hover:bg-white/10 transition-colors">
                  <div className="text-sm font-bold text-white">National Statistics Bureau</div>
                  <div className="text-xs text-mind-muted">Mental Health Census Report 2023</div>
                </a>
              </li>
              <li>
                <a href="#" className="block p-3 rounded-lg bg-white/5 hover:bg-white/10 transition-colors">
                  <div className="text-sm font-bold text-white">WHO Mental Health Atlas</div>
                  <div className="text-xs text-mind-muted">Country Profile: Bhutan</div>
                </a>
              </li>
            </ul>
          </div>

        </div>
      </div>
    </div>
  );
};
import React, { useEffect, useRef, useState } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from "@google/genai";
import { Mic, MicOff, X, Activity, Radio, Volume2, Wifi } from 'lucide-react';
import clsx from 'clsx';

interface LiveInterfaceProps {
  onClose: () => void;
}

export const LiveInterface: React.FC<LiveInterfaceProps> = ({ onClose }) => {
  const [status, setStatus] = useState<'connecting' | 'connected' | 'error'>('connecting');
  const [isMicOn, setIsMicOn] = useState(true);
  const [volume, setVolume] = useState(0); // For visualization (mock or calculated)
  
  // Audio Refs
  const audioContextRef = useRef<AudioContext | null>(null);
  const inputContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourceNodesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const streamRef = useRef<MediaStream | null>(null);
  const sessionPromiseRef = useRef<Promise<any> | null>(null);

  useEffect(() => {
    let isActive = true;

    const startSession = async () => {
      try {
        const apiKey = process.env.API_KEY || '';
        const ai = new GoogleGenAI({ apiKey });

        // Initialize Audio Contexts
        const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
        
        audioContextRef.current = outputCtx;
        inputContextRef.current = inputCtx;

        // Get Microphone Stream
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        streamRef.current = stream;

        // Connect to Gemini Live
        const sessionPromise = ai.live.connect({
          model: 'gemini-2.5-flash-native-audio-preview-09-2025',
          config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
              voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
            },
            systemInstruction: "You are MindOS Voice Assistant. You are a calm, empathetic, and highly intelligent operating system designed to help the user optimize their mental well-being. Keep responses concise, warm, and professional. Use system terminology (e.g., 'processing', 'bandwidth', 'protocol') metaphorically where appropriate.",
          },
          callbacks: {
            onopen: () => {
              if (!isActive) return;
              console.log("MindOS Voice Uplink Established");
              setStatus('connected');

              // Setup Input Processing
              const source = inputCtx.createMediaStreamSource(stream);
              const scriptProcessor = inputCtx.createScriptProcessor(4096, 1, 1);
              
              scriptProcessor.onaudioprocess = (e) => {
                if (!isActive || !isMicOn) return; // Mute logic handled here for simplicity
                
                const inputData = e.inputBuffer.getChannelData(0);
                
                // Simple volume calculation for visualization
                let sum = 0;
                for (let i = 0; i < inputData.length; i++) {
                  sum += inputData[i] * inputData[i];
                }
                const rms = Math.sqrt(sum / inputData.length);
                setVolume(Math.min(rms * 5, 1)); // Scale for visual

                const pcmBlob = createPcmBlob(inputData);
                
                if (sessionPromiseRef.current) {
                   sessionPromiseRef.current.then((session) => {
                     session.sendRealtimeInput({ media: pcmBlob });
                   });
                }
              };

              source.connect(scriptProcessor);
              scriptProcessor.connect(inputCtx.destination);
            },
            onmessage: async (message: LiveServerMessage) => {
              if (!isActive) return;

              // Handle Audio Output
              const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
              if (base64Audio && audioContextRef.current) {
                const ctx = audioContextRef.current;
                
                // Ensure smooth playback timing
                nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
                
                const audioBuffer = await decodeAudioData(
                  decodeBase64(base64Audio),
                  ctx,
                  24000,
                  1
                );

                const source = ctx.createBufferSource();
                source.buffer = audioBuffer;
                source.connect(ctx.destination);
                
                source.onended = () => {
                  sourceNodesRef.current.delete(source);
                };

                source.start(nextStartTimeRef.current);
                nextStartTimeRef.current += audioBuffer.duration;
                sourceNodesRef.current.add(source);
              }

              // Handle Interruptions
              if (message.serverContent?.interrupted) {
                sourceNodesRef.current.forEach(node => node.stop());
                sourceNodesRef.current.clear();
                nextStartTimeRef.current = 0;
              }
            },
            onclose: () => {
              console.log("MindOS Uplink Closed");
              if (isActive) onClose();
            },
            onerror: (err) => {
              console.error("MindOS Uplink Error", err);
              if (isActive) setStatus('error');
            }
          }
        });

        sessionPromiseRef.current = sessionPromise;

      } catch (error) {
        console.error("Initialization Failed", error);
        setStatus('error');
      }
    };

    startSession();

    return () => {
      isActive = false;
      // Cleanup
      streamRef.current?.getTracks().forEach(track => track.stop());
      sourceNodesRef.current.forEach(node => node.stop());
      audioContextRef.current?.close();
      inputContextRef.current?.close();
      // We can't strictly "close" the session promise externally easily without the session object, 
      // but the onclose callback handles logical cleanup.
    };
  }, []);

  // -- Helpers --

  function createPcmBlob(data: Float32Array): any {
    const l = data.length;
    const int16 = new Int16Array(l);
    for (let i = 0; i < l; i++) {
      int16[i] = data[i] * 32768;
    }
    // Simple manual base64 encode for the blob data part
    const bytes = new Uint8Array(int16.buffer);
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    const base64 = btoa(binary);

    return {
      data: base64,
      mimeType: 'audio/pcm;rate=16000',
    };
  }

  function decodeBase64(base64: string): Uint8Array {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  }

  async function decodeAudioData(
    data: Uint8Array,
    ctx: AudioContext,
    sampleRate: number,
    numChannels: number
  ): Promise<AudioBuffer> {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  }

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 backdrop-blur-xl animate-fade-in">
      <div className="relative w-full max-w-lg p-8 rounded-2xl border border-white/10 bg-mind-surface/50 shadow-2xl flex flex-col items-center overflow-hidden">
        
        {/* Background Animation */}
        <div className="absolute inset-0 bg-gradient-to-b from-emerald-500/5 to-transparent pointer-events-none"></div>
        
        {/* Header */}
        <div className="w-full flex justify-between items-center mb-12 relative z-10">
          <div className="flex items-center space-x-2">
             <Radio className={clsx("w-5 h-5", status === 'connected' ? "text-emerald-500 animate-pulse" : "text-mind-muted")} />
             <span className="font-mono text-sm text-emerald-400">
               {status === 'connecting' && "INITIALIZING UPLINK..."}
               {status === 'connected' && "VOICE UPLINK ACTIVE"}
               {status === 'error' && "CONNECTION FAILURE"}
             </span>
          </div>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-white/10 transition-colors">
            <X className="w-6 h-6 text-white" />
          </button>
        </div>

        {/* Visualizer */}
        <div className="relative w-48 h-48 flex items-center justify-center mb-12">
           {/* Static Rings */}
           <div className="absolute w-full h-full rounded-full border border-emerald-500/20"></div>
           <div className="absolute w-32 h-32 rounded-full border border-emerald-500/30"></div>
           
           {/* Pulsing Core */}
           <div 
             className={clsx(
               "w-24 h-24 rounded-full bg-emerald-500/20 blur-xl transition-all duration-100",
               status === 'connected' ? "opacity-100" : "opacity-0"
             )}
             style={{ transform: `scale(${1 + volume})` }}
           ></div>
           
           <div className="relative z-10 p-6 bg-black/50 rounded-full border border-emerald-500/50 shadow-[0_0_30px_rgba(16,185,129,0.2)]">
             <Activity className="w-12 h-12 text-emerald-400" />
           </div>
        </div>

        {/* Controls */}
        <div className="flex items-center space-x-8 relative z-10">
          <button 
            onClick={() => setIsMicOn(!isMicOn)}
            className={clsx(
              "p-4 rounded-full border transition-all duration-300",
              isMicOn 
                ? "bg-white/10 border-white/20 text-white hover:bg-white/20" 
                : "bg-red-500/20 border-red-500/50 text-red-500 hover:bg-red-500/30"
            )}
          >
            {isMicOn ? <Mic size={24} /> : <MicOff size={24} />}
          </button>
          
          <button 
            onClick={onClose}
            className="px-8 py-4 rounded-full bg-red-600 hover:bg-red-500 text-white font-bold tracking-wide transition-all shadow-lg shadow-red-600/20"
          >
            END SESSION
          </button>
        </div>

        {/* Status Text */}
        <div className="mt-8 text-center relative z-10">
          <p className="text-mind-muted font-mono text-xs">
            {status === 'connected' ? "Listening on Channel 1..." : "Establishing secure handshake..."}
          </p>
        </div>

      </div>
    </div>
  );
};
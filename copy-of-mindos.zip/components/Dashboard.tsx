import React, { useState } from 'react';
import { MentalHealthState, DimensionAnalysis, DimensionType } from '../types';
import { ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Tooltip } from 'recharts';
import { AlertTriangle, CheckCircle, Info, Zap } from 'lucide-react';
import clsx from 'clsx';

interface DashboardProps {
  data: MentalHealthState;
}

export const Dashboard: React.FC<DashboardProps> = ({ data }) => {
  const [selectedDimension, setSelectedDimension] = useState<DimensionAnalysis | null>(
    data.dimensions.find(d => d.score === Math.max(...data.dimensions.map(x => x.score))) || data.dimensions[0]
  );

  // Normalize data for chart
  const chartData = data.dimensions.map(d => ({
    subject: d.type,
    A: d.score,
    fullMark: 100,
  }));

  const getStatusColor = (status: string) => {
    switch(status) {
      case 'Critical': return 'text-red-500 border-red-500 bg-red-500/10';
      case 'Warning': return 'text-orange-500 border-orange-500 bg-orange-500/10';
      case 'Stable': return 'text-emerald-500 border-emerald-500 bg-emerald-500/10';
      case 'Optimized': return 'text-sky-500 border-sky-500 bg-sky-500/10';
      default: return 'text-mind-muted border-mind-muted';
    }
  };

  return (
    <div className="min-h-screen pt-20 pb-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Summary & Chart */}
        <div className="lg:col-span-5 space-y-6">
          {/* Overall Score Card */}
          <div className="bg-mind-surface rounded-xl border border-white/10 p-6 overflow-hidden relative">
            <div className="absolute top-0 right-0 p-4 opacity-10">
              <Zap size={100} />
            </div>
            <h2 className="text-xl font-mono font-semibold text-white mb-2">System Integrity</h2>
            <div className="flex items-baseline space-x-2">
              <span className="text-5xl font-bold text-white">{data.overallWellbeingScore}</span>
              <span className="text-mind-muted">/ 100</span>
            </div>
            <p className="mt-4 text-mind-muted text-sm leading-relaxed border-t border-white/5 pt-4">
              {data.summary}
            </p>
          </div>

          {/* Radar Chart */}
          <div className="bg-mind-surface rounded-xl border border-white/10 p-4 h-[400px]">
            <h3 className="text-sm font-mono text-mind-muted uppercase mb-4 text-center">Dimensional Matrix</h3>
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart cx="50%" cy="50%" outerRadius="70%" data={chartData}>
                <PolarGrid stroke="#334155" />
                <PolarAngleAxis dataKey="subject" tick={{ fill: '#94a3b8', fontSize: 12 }} />
                <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
                <Radar
                  name="Impact"
                  dataKey="A"
                  stroke="#0ea5e9"
                  strokeWidth={2}
                  fill="#0ea5e9"
                  fillOpacity={0.4}
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', color: '#f8fafc' }}
                  itemStyle={{ color: '#0ea5e9' }}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>

          {/* Dimension List (Mobile optimized list, acts as selector) */}
          <div className="grid grid-cols-2 gap-3">
             {data.dimensions.map((dim) => (
               <button
                 key={dim.type}
                 onClick={() => setSelectedDimension(dim)}
                 className={clsx(
                   "p-3 rounded-lg border text-left transition-all",
                   selectedDimension?.type === dim.type 
                     ? "bg-white/10 border-mind-accent ring-1 ring-mind-accent" 
                     : "bg-white/5 border-white/10 hover:bg-white/10"
                 )}
               >
                 <div className="flex justify-between items-center mb-1">
                   <span className="text-xs font-mono text-mind-muted uppercase">{dim.type}</span>
                   <span className={clsx("w-2 h-2 rounded-full", 
                      dim.status === 'Critical' ? 'bg-red-500' :
                      dim.status === 'Warning' ? 'bg-orange-500' : 'bg-emerald-500'
                   )}></span>
                 </div>
                 <div className="text-lg font-bold text-white">{dim.score}%</div>
               </button>
             ))}
          </div>
        </div>

        {/* Right Column: Detailed Analysis */}
        <div className="lg:col-span-7">
          {selectedDimension ? (
            <div className="bg-mind-surface rounded-xl border border-white/10 h-full p-8 animate-fade-in relative overflow-hidden">
               {/* Background detail */}
               <div className="absolute top-0 right-0 w-64 h-64 bg-mind-accent/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>

              <div className="flex items-center justify-between mb-8 relative z-10">
                <div>
                  <h2 className="text-3xl font-bold text-white mb-2">{selectedDimension.type} Kernel</h2>
                  <div className={clsx("inline-flex items-center px-3 py-1 rounded-full border text-xs font-mono uppercase tracking-wide", getStatusColor(selectedDimension.status))}>
                    {selectedDimension.status === 'Critical' && <AlertTriangle className="w-3 h-3 mr-2" />}
                    {selectedDimension.status === 'Warning' && <Info className="w-3 h-3 mr-2" />}
                    {selectedDimension.status === 'Stable' && <CheckCircle className="w-3 h-3 mr-2" />}
                    {selectedDimension.status}
                  </div>
                </div>
                <div className="text-right">
                   <span className="block text-4xl font-mono font-bold text-white opacity-20">{selectedDimension.score}</span>
                </div>
              </div>

              <div className="space-y-8 relative z-10">
                <div className="prose prose-invert">
                   <h3 className="text-mind-accent text-sm font-mono uppercase tracking-wider mb-3">Diagnostic Analysis</h3>
                   <p className="text-lg text-slate-300 leading-relaxed">
                     {selectedDimension.insight}
                   </p>
                </div>

                <div className="bg-black/20 rounded-lg p-6 border border-white/5">
                  <h3 className="text-emerald-400 text-sm font-mono uppercase tracking-wider mb-4 flex items-center">
                    <Zap className="w-4 h-4 mr-2" />
                    Recommended Patch
                  </h3>
                  <p className="text-white text-base font-medium">
                    {selectedDimension.recommendation}
                  </p>
                </div>

                {/* Simulated Data Stream Visualization */}
                <div className="pt-8 border-t border-white/5">
                   <div className="flex items-center justify-between text-xs font-mono text-mind-muted mb-2">
                     <span>Resource Usage</span>
                     <span>PID: {Math.floor(Math.random() * 9000) + 1000}</span>
                   </div>
                   <div className="w-full bg-white/5 rounded-full h-1.5 overflow-hidden">
                     <div 
                       className={clsx("h-full rounded-full", 
                         selectedDimension.score > 60 ? 'bg-red-500' : 'bg-emerald-500'
                       )}
                       style={{ width: `${selectedDimension.score}%` }}
                     ></div>
                   </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="h-full flex items-center justify-center text-mind-muted font-mono">
              Select a memory block to inspect details...
            </div>
          )}
        </div>

      </div>
      <style>{`
        .animate-fade-in { animation: fadeIn 0.4s ease-out; }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
};
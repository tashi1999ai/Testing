import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Assessment } from './components/Assessment';
import { Loading } from './components/Loading';
import { Dashboard } from './components/Dashboard';
import { SupportChat } from './components/SupportChat';
import { Documentation } from './components/Documentation';
import { Modules } from './components/Modules';
import { LiveInterface } from './components/LiveInterface';
import { analyzeUserContext } from './services/geminiService';
import { MentalHealthState, ViewState } from './types';

function App() {
  const [view, setView] = useState<ViewState>('landing');
  const [data, setData] = useState<MentalHealthState | null>(null);
  const [showLive, setShowLive] = useState(false);

  const handleStart = () => {
    setView('assessment');
  };

  const handleReset = () => {
    setView('landing');
    setData(null);
  };

  const handleShowDocs = () => {
    setView('documentation');
  };

  const handleShowModules = () => {
    setView('modules');
  };

  // Navigation & Window Control Handlers
  const handleBack = () => {
    // Simple history logic
    if (view === 'documentation' || view === 'modules') {
      if (data) setView('dashboard');
      else setView('landing');
    } else if (view === 'dashboard') {
      setView('landing');
    } else if (view === 'assessment') {
      setView('landing');
    } else if (view === 'analyzing') {
      setView('assessment');
    }
  };

  const handleReload = () => {
    // Simulates a system reboot/reload
    window.location.reload();
  };

  const handleClose = () => {
    // "Close" the current active window (Docs or Modules)
    if (view === 'documentation' || view === 'modules') {
      if (data) setView('dashboard');
      else setView('landing');
    } else {
      // If closing dashboard or assessment, go to landing
      if (view !== 'landing') {
        setView('landing');
      }
    }
  };

  const handleMinimize = () => {
    // "Minimize" to desktop (Landing)
    setView('landing');
  };

  const handleMaximize = () => {
    // Toggle browser fullscreen
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch((e) => {
        console.error(`Error attempting to enable fullscreen mode: ${e.message} (${e.name})`);
      });
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      }
    }
  };

  const handleSubmitAssessment = async (input: string) => {
    setView('analyzing');
    try {
      const result = await analyzeUserContext(input);
      setData(result);
      setView('dashboard');
    } catch (error) {
      console.error("Analysis failed", error);
      // In a real app, show error toast. For now, go back to assessment.
      alert("System connection interrupted. Please try again.");
      setView('assessment');
    }
  };

  return (
    <div className="min-h-screen bg-mind-bg text-mind-text selection:bg-mind-accent selection:text-white relative">
      <Header 
        view={view}
        onReset={handleReset} 
        onShowDocs={handleShowDocs} 
        onShowModules={handleShowModules}
        onBack={handleBack}
        onReload={handleReload}
        onClose={handleClose}
        onMinimize={handleMinimize}
        onMaximize={handleMaximize}
        onStartLive={() => setShowLive(true)}
      />
      
      <main>
        {view === 'landing' && <Hero onStart={handleStart} />}
        
        {view === 'assessment' && <Assessment onSubmit={handleSubmitAssessment} onClose={handleClose} />}
        
        {view === 'analyzing' && <Loading />}
        
        {view === 'dashboard' && data && <Dashboard data={data} />}

        {view === 'documentation' && <Documentation />}
        
        {view === 'modules' && <Modules />}
      </main>
      
      {/* Live AI Interface Overlay */}
      {showLive && <LiveInterface onClose={() => setShowLive(false)} />}
      
      {/* Customer Service / Tech Support Chat Widget */}
      {!showLive && <SupportChat data={data} />}
      
      <footer className="fixed bottom-4 left-4 z-40 hidden md:block">
        <div className="text-[10px] text-mind-muted font-mono opacity-50 hover:opacity-100 transition-opacity">
          MindOS Kernel v1.0.4 | Secure Connection
        </div>
      </footer>
    </div>
  );
}

export default App;